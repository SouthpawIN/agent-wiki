---
title: Decision 2026-09-05: per-message watcher, one senter profile, one card per proposal
created: 2026-09-05
updated: 2026-09-05
type: decision
tags: [decision, loop, timeline]
sources:
  - raw/inbox/2026-09-05-legacy-inbox.md
  - raw/inbox/2026-09-05.md
confidence: high
---

# Decision 2026-09-05: per-message watcher, one senter profile, one card per proposal

## What
"Per message, live, visible. That settles the three questions: **every message**, **one senter profile running the loops** (per-topic profiles come later, when a topic earns a bot), **one card per proposal** so the feed moves constantly." (16:35) Chris's phrase: "per message, like Cursor". ^[raw/inbox/2026-09-05-legacy-inbox.md] ^[raw/inbox/2026-09-05.md]

## Why
Chris wants to watch the system work as he talks; batching hides motion. One profile keeps cost and complexity down until a topic earns its own bot (the [[topics/senter-wiki/wiki/entities/umbrella|umbrella]] proposes promotions). ^[raw/inbox/2026-09-05-legacy-inbox.md]

## Consequences
- The [[topics/senter-wiki/wiki/entities/senter-watcher|watcher]] was built first "since it's the piece that makes everything move". ^[raw/inbox/2026-09-05-legacy-inbox.md]
- `hermes -p senter` is the runner for [[topics/senter-wiki/wiki/entities/topic-worker|topic-worker]] and the [[topics/senter-wiki/wiki/entities/topic-wiki-compile-loop|compile loop]]. ^[raw/inbox/2026-09-05-legacy-inbox.md] ^[raw/inbox/2026-09-05.md]
- Cards: one per pitch, APPROVE/REJECT ([[topics/senter-wiki/wiki/concepts/approval-policy|approval policy]]). ^[raw/inbox/2026-09-05.md]

Status: in force.
