---
title: Decision 2026-09-05: every topic is a Karpathy-style LLM wiki; CONTEXT renders index.md
created: 2026-09-05
updated: 2026-09-05
type: decision
tags: [decision, spec, tool]
sources:
  - raw/inbox/2026-09-05.md
  - raw/inbox/2026-09-05-legacy-inbox.md
confidence: high
---

# Decision 2026-09-05: every topic is a Karpathy-style LLM wiki

## What
"You're right, and I'd been misreading 'context' as a summary line. Fixed at the root, using the `llm-wiki` skill as you said: **Every topic is now a Karpathy-style LLM wiki** (`assets/topic-wiki.py`)." (17:43) `raw/` immutable Layer 1 (watcher files `raw/inbox/<day>.md`; transcripts/specs/source moved to `raw/sources/`, symlinked from old `.system/` paths); `wiki/{entities,concepts,decisions,comparisons,queries}` Layer 2; `SCHEMA.md`, `index.md`, `log.md`. ^[raw/inbox/2026-09-05.md]

## Why
Chris corrected the 220-character summary notion of "context": the CONTEXT section must be the topic's whole compiled knowledge, browsable — "every page, one line each, wikilinked … Not 220 characters." ^[raw/inbox/2026-09-05.md]

## Effects
- Compile loop `com.senter.topic-wiki` every 15 min ([[topics/senter-wiki/wiki/entities/topic-wiki-compile-loop|entity]]); all 19 topics initialised; first compiles of senter + senter-wiki (5 MB raw) started in background. ^[raw/inbox/2026-09-05.md]
- UI: CONTEXT renders full `index.md`; context orb = page count. ^[raw/inbox/2026-09-05-legacy-inbox.md] — **superseded 19:06**: CONTEXT now renders the pages themselves with live diffs and no counts ([[topics/senter-wiki/wiki/decisions/2026-09-05-context-is-the-wiki-with-live-diffs|decision]]). ^[raw/inbox/2026-09-05.md]
- Watcher restarted for the new raw layer. ^[raw/inbox/2026-09-05.md]

Concept page: [[topics/senter-wiki/wiki/concepts/llm-wiki-topic-layout|LLM-wiki topic layout]]. Predecessor knowledge structure: [[topics/senter-wiki/wiki/entities/agent-wiki-repo|agent-wiki spec]] (`.system/continuity.md` as "raw understanding").
