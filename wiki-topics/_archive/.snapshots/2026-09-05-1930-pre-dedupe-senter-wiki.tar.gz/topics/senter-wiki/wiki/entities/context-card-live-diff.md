---
title: "Context card live diff — watching the topic agent edit the wiki (+N −M, green/red lines)"
created: 2026-09-05
updated: 2026-09-05
type: entity
tags: [ui, spec, tool]
sources:
  - raw/inbox/2026-09-05.md
confidence: high
---

# Context card live diff

The CONTEXT card of a topic row, after the 19:06 decision ([[topics/senter-wiki/wiki/decisions/2026-09-05-context-is-the-wiki-with-live-diffs|CONTEXT is the wiki with live diffs]]). It replaces the `index.md` listing and the page/raw counts.

## What it renders
The topic's actual `wiki/` pages, grouped by section — ENTITIES / CONCEPTS / DECISIONS / COMPARISONS / QUERIES — each page as its title plus rendered markdown, fetched through the [[topics/senter-wiki/wiki/entities/senter-bridge|bridge]] when the card opens (64 pages for `senter` at 19:12). No counts, no index list. ^[raw/inbox/2026-09-05.md]

## How a diff arrives (as reported 19:12, "DOM-proven")
1. The topic agent ([[topics/senter-wiki/wiki/entities/topic-wiki-compile-loop|compile loop]]) snapshots the wiki before its run and diffs every changed page after.
2. Each changed page becomes a `diff` event into the UI (new event kind next to `message` / `tool` / `skill` / `approval` / `wiki` in [[topics/senter-wiki/wiki/concepts/ui-performs-the-fleet|handle(ev)]]).
3. The UI scrolls that page into view and repaints it: removed lines red and struck through, added lines green; a `+N −M` badge on the page and a running badge beside the card title — Chris's *"plus-minus lines in the red and green like what you would see on like Github."*
4. It settles to plain text after **6 s**.
5. If the card is closed it **peeks open for the edit (9 s)** — unless Chris has a card pinned (the "you always win" rule from stage events carries over). ^[raw/inbox/2026-09-05.md]

## Geometry
The card's right edge stops 14 px short of the side chat (684 vs chat at 698) so the feed and the player stay live while he reads — [[topics/senter-wiki/wiki/decisions/2026-09-05-content-card-stops-at-side-chat|decision]]. ^[raw/inbox/2026-09-05.md]

## Open on this element
- Full markdown rendering inside the card: *"make sure that all of the markdown actually renders — so the title is actually pop up as titles."* `md()` coverage vs what compiled pages use (tables, frontmatter, `^[…]` provenance, `[[wikilinks|Title]]`) was being checked at 19:19. ^[raw/inbox/2026-09-05.md]
- What the context **orb** shows now that counts are banned from the card — unsettled ([[topics/senter-wiki/wiki/entities/hero-orbs|hero orbs]]).
- "organize this by sections and command" — the *command* half is undefined.
