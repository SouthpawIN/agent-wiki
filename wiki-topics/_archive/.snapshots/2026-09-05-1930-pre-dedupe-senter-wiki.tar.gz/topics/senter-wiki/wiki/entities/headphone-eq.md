---
title: Headphone EQ visualiser (#hpEq)
created: 2026-09-05
updated: 2026-09-05
type: entity
tags: [ui, music]
sources:
  - raw/sources/knowledge/ref-vault-live-eq-feed-2026-09-03.md
  - raw/inbox/2026-09-05-legacy-inbox.md
  - raw/sources/knowledge/skill-agent-wiki-vault.md
  - raw/sources/knowledge/ref-vault-live-palette.md
confidence: high
---

# Headphone EQ visualiser (#hpEq)

## Chris's ask
"an EQ visualizer, small, over the widest part of the inner circle of the girl's headphones … black dots representing the levels going up and down, because black on white will be a good contrast." ^[raw/sources/knowledge/ref-vault-live-eq-feed-2026-09-03.md]

## Placement
Anchored to the [[topics/senter-wiki/wiki/entities/wallpaper-girl|wallpaper's DRAWN rect]] (contain/centre, `WALL_AR=1.54`), same math as `orbColumn()`: `dw=min(W,H*AR); dh=dw/AR; il=(W-dw)/2; it=(H-dh)/2; left=il+dw*CX−w/2`. Knobs `--eqCX/--eqCY` (final 0.8282 / 0.3937), `--eqW/--eqH` (3.2 / 4.6 % of drawn size), `COLS=7 ROWS=6`. Finding the disc: pixel scans grabbed hair; a tight `vision_analyze` crop asking for the innermost flat plate bbox worked (centre 1190,362 of 1456×914). 2px ≈ 0.0011 w / 0.0017 h. ^[raw/sources/knowledge/ref-vault-live-eq-feed-2026-09-03.md]

## "They look gray, not black" — three rounds
1. Not layering (z-index changed nothing). 2. Idle dots at 14–28 % opacity — with nothing playing EVERY dot is idle → whole grid gray. 3. 3.5px circles anti-alias to gray on 2×. Fix: every dot `#000`, `opacity:1`, 4.5px; level = SIZE (`scale(.44)` unlit → `none` lit), never opacity. "His picture is pure black/white ink + cross-hatch — any translucency reads as a mistake." Exempt from the paper knob ([[topics/senter-wiki/wiki/concepts/paper-palette|paper palette]]). ^[raw/sources/knowledge/ref-vault-live-eq-feed-2026-09-03.md] ^[raw/sources/knowledge/ref-vault-live-palette.md]

## Levels
Web Audio analyser (`createMediaElementSource` on `#radioAudio` / `#plStage audio,video`, `fftSize 64`, 7 bands over the low 60 % of bins, ×1.25). YouTube iframes expose no audio → breathing pattern; since 2026-09-05 the bridge audio proxy gives real levels (40/42 cells lit on Godhood) — [[topics/senter-wiki/wiki/entities/music-player|music player]]. Demo `window.hpEq.demo(sec)` (kick cols 0–1 at 2 Hz, wandering mids, hats cols 5–6); the `?eqdemo` URL flag is stripped by the pane, so a fixed `<button id="hpEqDemo">` was the trigger (removed at MVP checkpoint). Wording: "runs for 30 seconds" — "30 seconds from now" read as a delay. ^[raw/sources/knowledge/ref-vault-live-eq-feed-2026-09-03.md] ^[raw/sources/knowledge/skill-agent-wiki-vault.md]

Its left edge `--eqLeft` defines the media zone for the [[topics/senter-wiki/wiki/entities/volume-rocker|rocker]]. ^[raw/inbox/2026-09-05-legacy-inbox.md]
