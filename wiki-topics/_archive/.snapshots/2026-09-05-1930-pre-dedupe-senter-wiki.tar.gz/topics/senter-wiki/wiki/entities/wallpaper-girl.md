---
title: The wallpaper girl (backdrop asset)
created: 2026-09-05
updated: 2026-09-05
type: entity
tags: [ui]
sources:
  - raw/sources/knowledge/ref-vault-live-palette.md
  - raw/sources/knowledge/ref-vault-live-eq-feed-2026-09-03.md
  - raw/sources/knowledge/ref-vault-live-ui-2026-09-03.md
  - raw/sources/knowledge/ref-vault-live-hud-2026-09-03.md
confidence: high
---

# The wallpaper girl (backdrop asset)

## What it is
Chris's desktop wallpaper — a white-on-black ink drawing of a girl with headphones (`assets/wall-contain-1456x914-wallonly.png`, aspect `WALL_AR=1.54`) drawn `contain` + centred as `#wallBackdrop`. Several UI anchors are measured off her: row-dot column ends at her fingertips (`figLeft`, `__figFrac` fallback .62), the [[topics/senter-wiki/wiki/entities/headphone-eq|EQ]] sits on her headphone plate, the [[topics/senter-wiki/wiki/entities/hud-cluster|HUD]] axis is the midpoint between the back of her head (`HEAD_BACK 0.905`) and the pane edge, her face forward is the dead zone. ^[raw/sources/knowledge/ref-vault-live-ui-2026-09-03.md] ^[raw/sources/knowledge/ref-vault-live-eq-feed-2026-09-03.md] ^[raw/sources/knowledge/ref-vault-live-hud-2026-09-03.md]

## Rule: pin overlays to the DRAWN rect
`dw=min(W,H*AR); dh=dw/AR; il=(W-dw)/2; it=(H-dh)/2` — never the viewport. Px nudges convert to fractions (2px ≈ 0.0011 w / 0.0017 h). ^[raw/sources/knowledge/ref-vault-live-eq-feed-2026-09-03.md]

## She must BE the paper colour
Her asset is only ~60 % luminance (p99 = 153/255) with JPEG near-blacks. Three failed approaches (brightness filter → read warm later; sepia/hue-rotate → "still cream"; paper bg + multiply → neutral grey that reads WARM, plus a "gray bar along the bottom" from the element background under the contain image). Working: the picture is a **luminance mask** over a flat `var(--paper)` fill, stacked twice (`::before/::after`, `--wallInk`), so her ink pixels are exactly the paper colour and black stays black. Pixel-verified: ink (192–200,192–200,208–216) vs UI text (200,200,216); bottom strip (0,0,0). Details: [[topics/senter-wiki/wiki/concepts/paper-palette|paper palette]]. ^[raw/sources/knowledge/ref-vault-live-palette.md]

Anything drawn over her: solid `#000`, `opacity:1`, ≥4px; state by size, never translucency. ^[raw/sources/knowledge/skill-agent-wiki-vault.md]
