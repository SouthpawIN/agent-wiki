---
title: Fleet bots touching senter-wiki
created: 2026-09-05
updated: 2026-09-05
type: entity
tags: [bot]
sources:
  - raw/sources/knowledge/skill-agent-wiki-vault.md
  - raw/inbox/2026-09-05-legacy-inbox.md
  - raw/sources/knowledge/ref-vault-live-ui-2026-09-03.md
  - raw/sources/knowledge/ref-vault-live-concept-2026-09-03.md
  - raw/sources/knowledge/agent-wiki-repo/goop-whitepaper.md
confidence: medium
---

# Fleet bots touching senter-wiki

Senter's fleet as it appears in this topic's sources (roster of 9 on 2026-09-05; bots, not "agents"). ^[raw/inbox/2026-09-05-legacy-inbox.md]

| Bot | Role seen here | Notes |
|---|---|---|
| **senter** | coordinator; the ONE profile running the topic loops for now ("per-topic profiles come later, when a topic earns a bot") | [[topics/senter-wiki/wiki/decisions/2026-09-05-per-message-watcher-one-profile-one-card|decision]] ^[raw/inbox/2026-09-05-legacy-inbox.md] |
| **anser** | redundancy gate / "native before custom": asked what Hermes already ships, then VERIFY read-only — "Anser hallucinates features". `hermes -p anser -z "<q>. Plain text, no MEDIA, no TL;DR — internal fleet conversation."` (~15 s); SOUL forces Discord TL;DR+MEDIA otherwise. Co-author of the GOOP whitepaper. | ^[raw/sources/knowledge/skill-agent-wiki-vault.md] ^[raw/sources/knowledge/agent-wiki-repo/goop-whitepaper.md] |
| **looker** | UI-QA / research: receives the instant research dispatch when a new subject scaffolds a topic | ^[raw/inbox/2026-09-05-legacy-inbox.md] |
| **klerik** | profile factory; example BOTS row hovered in the editor verification (`#bots/klerik`, SOUL.md loaded) | ^[raw/sources/knowledge/ref-vault-live-ui-2026-09-03.md] |
| **teknium** | Hermes builder; 09-02 note that `hermes auth spotify` was never run | ^[raw/inbox/2026-09-05-legacy-inbox.md] |
| **weaver** | wiki UI owner (memory) | — |
| **senter-wiki-bot** | PROPOSED by the [[topics/senter-wiki/wiki/entities/umbrella|umbrella]]: 4 skills, no agent | awaiting Chris ^[raw/inbox/2026-09-05-legacy-inbox.md] |
| **sidebar** (proposed SOUL) | see [[topics/senter-wiki/wiki/entities/sidebar-agent|sidebar agent]] | awaiting approval ^[raw/inbox/2026-09-05-legacy-inbox.md] |

Per the concept page, Bot = "specialised sub-worker of that Agent (a profile with SOUL.md)". ^[raw/sources/knowledge/ref-vault-live-concept-2026-09-03.md]

Roster rendering: the BOTS section of [[topics/senter-wiki/wiki/entities/vault-live-html|vault-live.html]] sorts bots by SOUL role text, not title ([[topics/senter-wiki/wiki/concepts/similarity-ranking|similarity and ranking]]).
