---
title: topic-worker — per-topic GEPA proposal loop
created: 2026-09-05
updated: 2026-09-05
type: entity
tags: [loop, infra]
sources:
  - raw/inbox/2026-09-05-legacy-inbox.md
  - raw/sources/knowledge/skill-agent-wiki-vault.md
confidence: high
---

# topic-worker — per-topic GEPA proposal loop

## What it is
`assets/topic-worker.py`, launchd every 5 min: one real `hermes -p senter` run per topic over the [[topics/senter-wiki/wiki/entities/senter-watcher|watcher's]] inbox, running the GEPA cycle collect → generate → evaluate → apply ([[topics/senter-wiki/wiki/concepts/factory-pipeline-gepa|factory pipeline]]). Originally wrote `.proposed` files only. ^[raw/inbox/2026-09-05-legacy-inbox.md]

## First real pass (2026-09-05)
On Chris's actual messages it produced 5 skill proposals — e.g. `sidebar-rubber-duck` "quotes you verbatim as evidence and reads as a real SKILL.md" — and 8 continuity lines. ^[raw/inbox/2026-09-05-legacy-inbox.md]

## Policy change same day
After [[topics/senter-wiki/wiki/decisions/2026-09-05-approvals-only-bots-and-loops|approvals only for bots and loops]], the topic-worker writes `SKILL.md` directly (the 5 pending skills were promoted). Only bots and loops stay `.proposed`. Every worker skill/continuity write emits a `/stage` event. ^[raw/inbox/2026-09-05-legacy-inbox.md]

## Staged status
Listed as PROPOSED in the loops lane when the topic was built (16:51), running by 17:14 ("The flywheel is running end to end"). ^[raw/inbox/2026-09-05-legacy-inbox.md]

Related: [[topics/senter-wiki/wiki/entities/umbrella|umbrella]] (cross-topic), [[topics/senter-wiki/wiki/entities/topic-wiki-compile-loop|topic-wiki compile loop]] (Layer-2 compile), [[topics/senter-wiki/wiki/entities/senter-agent-sandbox|Senter Agent runtime]] for the original proposal-only MVP boundary this descends from.
