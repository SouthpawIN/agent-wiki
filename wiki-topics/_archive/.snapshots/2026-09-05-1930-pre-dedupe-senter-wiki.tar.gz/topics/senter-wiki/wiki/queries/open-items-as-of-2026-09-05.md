---
title: Open items and things waiting on Chris (as of 2026-09-05 19:19)
created: 2026-09-05
updated: 2026-09-05 19:19
type: query
tags: [question, plan]
sources:
  - raw/inbox/2026-09-05-legacy-inbox.md
  - raw/inbox/2026-09-05.md
  - raw/sources/knowledge/ref-vault-live-concept-2026-09-03.md
  - raw/sources/knowledge/ref-vault-live-hover-usage-2026-09-03.md
  - raw/sources/knowledge/ref-vault-live-ui-2026-09-03.md
confidence: high
---

# Open items and things waiting on Chris (as of 2026-09-05 19:19)

## Chris's latest asks (19:06–19:18), not yet reported done
- **Row dots expand from the hovered dot** — *"when I hover over the third dot and it expands, the third dot should still be under my mouse."* [[topics/senter-wiki/wiki/decisions/2026-09-05-row-dots-expand-from-hovered-dot|decision]] ^[raw/inbox/2026-09-05.md]
- **All markdown renders in the CONTEXT card** — *"the title is actually pop up as titles on this stuff within the context."* Hermes was checking `md()` vs page syntax at 19:19. [[topics/senter-wiki/wiki/entities/context-card-live-diff|live diff card]] ^[raw/inbox/2026-09-05.md]
- **Pre-prompting / pre-planning for the compile step**, "useful for anyone" — [[topics/senter-wiki/wiki/concepts/compile-pre-planning|compile pre-planning]]. ^[raw/inbox/2026-09-05.md]
- **"organize this by sections and command"** — sections done; "command" undefined. ^[raw/inbox/2026-09-05.md]
- Context orb number vs *"I don't want any numbers indicating what's in the wiki"* — unsettled ([[topics/senter-wiki/wiki/decisions/2026-09-05-context-is-the-wiki-with-live-diffs|contested decision]]).
- ~~Card overlaps chat/player~~ and ~~CONTEXT as index list~~ — closed 19:12, DOM-proven (card edge 684 vs chat 698; pages rendered by section with live `+N −M` diffs). ^[raw/inbox/2026-09-05.md]

## Waiting on Chris
- **Spotify client ID** — only he can create it (developer.spotify.com → app → redirect `http://127.0.0.1:43827/spotify/callback` → `hermes auth spotify`). [[topics/senter-wiki/wiki/entities/music-player|music player]] ^[raw/inbox/2026-09-05-legacy-inbox.md]
- **senter-wiki → senter merge** — umbrella says merge (0.65); Senter kept apart; veto file `topics/_global/.system/keep-separate.md`. [[topics/senter-wiki/wiki/decisions/2026-09-05-keep-senter-and-senter-wiki-separate|decision (contested)]] ^[raw/inbox/2026-09-05-legacy-inbox.md]
- **`senter-wiki-bot`** promotion (4 skills, no agent) — APPROVE/REJECT card. ^[raw/inbox/2026-09-05-legacy-inbox.md]
- **Two skill dedupes** proposed by the umbrella. ^[raw/inbox/2026-09-05-legacy-inbox.md]
- **Sidebar SOUL rewrite** — proposed text in `topics/senter-wiki/agents/README.md`. [[topics/senter-wiki/wiki/entities/sidebar-agent|sidebar agent]] ^[raw/inbox/2026-09-05-legacy-inbox.md]

## Not done (engineering)
- Kanban claims — lock files for now; restated 19:12 as the next native candidate ([[topics/senter-wiki/wiki/concepts/collapse-toward-hermes-native|collapse toward native]]). ^[raw/inbox/2026-09-05-legacy-inbox.md] ^[raw/inbox/2026-09-05.md]
- `hermes serve approval.*` transport — bridge `/approve` is the stand-in; restated 19:12. ^[raw/inbox/2026-09-05-legacy-inbox.md] ^[raw/inbox/2026-09-05.md]
- Watcher thin-corpus misclassification (kashik 0.08) — self-heals as wikis fill. ^[raw/inbox/2026-09-05.md]
- ~~Compile results for senter + senter-wiki~~ — landed 18:14: senter 60 pages, senter-wiki 55 ([[topics/senter-wiki/wiki/queries/first-compile-results-2026-09-05|results]]). ^[raw/inbox/2026-09-05.md]
- ~~Card resolution pending~~ — 18:57: "Both loops registered and gateways for paladin and looker auto-installed by the apply path. Three bots now have live crons that actually fire" ([[topics/senter-wiki/wiki/queries/apply-path-proven-2026-09-05|apply path proven]]). Still open from that plan: a **bot** apply proven end-to-end, and "check the feed/UI state" — the crons' firings have not yet been shown in Chris's window. ^[raw/inbox/2026-09-05.md]
- Wiki record of the newly live crons (which two loops, which third bot) — "Update the wiki's record" was the stated next step; the raw does not name them. ^[raw/inbox/2026-09-05.md]
- Within-topic duplicate pages from two compiles over one raw set ([[topics/senter-wiki/wiki/queries/duplicate-page-candidates|17 candidate pairs]]).
- Dead code to remove when convenient: `.heroOrbsClone` / `--dotsc` mirroring, `wikiIdots()`, hardcoded 5-topic `TOPICS`/`rotateHero` table (bridged, not folded in). ^[raw/sources/knowledge/ref-vault-live-concept-2026-09-03.md] ^[raw/sources/knowledge/ref-vault-live-hover-usage-2026-09-03.md] ^[raw/sources/knowledge/skill-agent-wiki-vault.md]
- `.sdots` tag pills clip in the fixed row → planned hover card like the old GitHub mark. ^[raw/sources/knowledge/ref-vault-live-ui-2026-09-03.md]
- Editor-card buttons queued: LOCK (bridge `/write`), HISTORY (log.md), ASK, OPEN IN OBSIDIAN. ^[raw/sources/knowledge/skill-agent-wiki-vault.md]

## Open conversations
- Where merge/split governance lives now that the umbrella collapsed into the topic agent — surfaced by the senter compile, unanswered. ^[raw/inbox/2026-09-05.md]
- LOOPS semantics — "we can have a back and forth about concepts". ^[raw/sources/knowledge/ref-vault-live-concept-2026-09-03.md]
- "we're gonna be using the dots for one more thing" — unspecified. ^[raw/sources/knowledge/ref-vault-live-hover-usage-2026-09-03.md]

Filed because these are the questions Chris will ask next session; update rather than duplicate.
