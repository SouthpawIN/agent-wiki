---
title: Approval policy — only bots and loops need APPROVE; everything else auto-applies
created: 2026-09-05
updated: 2026-09-05
type: concept
tags: [decision, spec]
sources:
  - raw/inbox/2026-09-05-legacy-inbox.md
  - raw/inbox/2026-09-05.md
  - raw/sources/knowledge/agent-wiki-repo/spec.md
  - raw/sources/knowledge/agent-wiki-repo/SENTER_AGENT.md
  - raw/sources/knowledge/skill-agent-wiki-vault.md
confidence: high
---

# Approval policy — only bots and loops need APPROVE

## Current rule (Chris, 2026-09-05 ~17:19)
"No approvals for topics, edits, continuity, or skills — they auto-apply … Only bots and loops remain `.proposed` with APPROVE/REJECT — they cost money and run unattended." Formalised in [[topics/senter-wiki/wiki/decisions/2026-09-05-approvals-only-bots-and-loops|decision]]. ^[raw/inbox/2026-09-05-legacy-inbox.md]

## Mechanics
- Proposals are `.proposed` files in the topic lanes; the [[topics/senter-wiki/wiki/entities/scan-topics|scanner]] renders them as rows with a hollow ring + PROPOSED tag in SKILLS/BOTS/LOOPS; the pinned card gets **APPROVE** (`#FFE45A`) / **REJECT**. ^[raw/inbox/2026-09-05-legacy-inbox.md]
- [[topics/senter-wiki/wiki/entities/senter-bridge|Bridge]] `POST /approve` "does exactly two things — drop `.proposed` or delete." `hermes serve approval.*` transport is the eventual path; the bridge is the stand-in. ^[raw/inbox/2026-09-05-legacy-inbox.md]
- "Each pitch is one card with APPROVE/REJECT" in the [[topics/senter-wiki/wiki/entities/corner-feed|corner feed]]; one card per proposal so the feed moves constantly. ^[raw/inbox/2026-09-05.md] ^[raw/inbox/2026-09-05-legacy-inbox.md]
- Topic-merge vetoes go in `topics/_global/.system/keep-separate.md`. ^[raw/inbox/2026-09-05-legacy-inbox.md]

## Lineage
Spec-era: the Senter Agent planner was "read-only and proposal-only"; profile creation, cron/webhook deployment and live skill writes "require a later approval/enforcement layer". ^[raw/sources/knowledge/agent-wiki-repo/SENTER_AGENT.md] The 09-05 rule is that layer, narrowed to the two costly primitives.

## Standing user authority
Chris's memory-level rule: act first; confirm only spending, deletion, publishing. Scanner restarts (kill running agents) still need his approval each time. ^[raw/sources/knowledge/skill-agent-wiki-vault.md]

## What was waiting on him at 17:14
5 skills (auto-promoted minutes later), 1 bot (`senter-wiki-bot`), 1 merge (senter-wiki → senter), 2 dedupes. See [[topics/senter-wiki/wiki/queries/open-items-as-of-2026-09-05|open items]]. ^[raw/inbox/2026-09-05-legacy-inbox.md]
