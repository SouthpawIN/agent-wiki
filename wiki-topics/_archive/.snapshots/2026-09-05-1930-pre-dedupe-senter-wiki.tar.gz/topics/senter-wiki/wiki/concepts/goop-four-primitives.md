---
title: GOOP: Context → Skills → Bots → Loops
created: 2026-09-05
updated: 2026-09-05
type: concept
tags: [spec, idea, plan]
sources:
  - raw/sources/knowledge/ref-vault-live-concept-2026-09-03.md
  - raw/sources/knowledge/agent-wiki-repo/spec.md
  - raw/sources/knowledge/agent-wiki-repo/SENTER.md
  - raw/sources/knowledge/agent-wiki-repo/goop-nesting.md
  - raw/sources/knowledge/agent-wiki-repo/README.md
confidence: high
---

# GOOP four primitives

Chris's own framing (2026-09-03, saved verbatim in `topics/senter/.system/concept.md`):

> Hermes makes Skills out of repeated asks. Context -> Skills. … Bots make sense when a collection of Skills requires its own continuity/learning … When a Bot
> has a purpose, naturally a Loop springs out. Context -> Skills -> Bots -> Loops (and those four dots denote and sort by these four objects). … ALL represented
> in Markdown (knowledge base, SKILLS.md, AGENTS/SOUL/{WHATEVER}.md, and CRON/Hook scheduling).
^[raw/sources/knowledge/ref-vault-live-concept-2026-09-03.md]

## The spec's table
| Primitive | Factory | Hermes write | Wiki path |
|---|---|---|---|
| Context | Context | `write_file` | `topics/<t>/.system/` + `README.md` |
| Loops | Loops | `cronjob(create)`, kanban | `topics/<t>/loops/` |
| Agents (Bots) | Agents | `hermes profile create` + SOUL.md | `topics/<t>/agents/` |
| Skills | Skills | `skill_manage(create)` | `topics/<t>/skills/` |
Nesting (spec/goop-nesting): Context contains Loops which invoke Agents which load Skills; each factory's output is the next factory's input — *"idea → context →
skill → agent → loop, all automatic."* Note the two orderings coexist: Chris's emergence order (Context→Skills→Bots→Loops, which the four orbs follow) vs the spec's
containment order (Context→Loops→Agents→Skills). ^[raw/sources/knowledge/agent-wiki-repo/spec.md] ^[raw/sources/knowledge/agent-wiki-repo/goop-nesting.md]

## GEPA lifecycle for every primitive
Collect evidence → Generate candidates → Evaluate (redundancy, contradictions, evidence alignment, safety) → Apply only an approved winner. *"Skills should emerge
from repeated evidence, not be created merely because a capability was mentioned once."* Agents only when the skill cluster is strong; Loops only after an agent
workflow is stable. ^[raw/sources/knowledge/agent-wiki-repo/SENTER.md]

## Flywheel (spec)
1 Chris speaks → session DB · 2 Context reads sessions, writes wiki pages · 3 queue items `[SKILLS] [AGENTS] [LOOPS]` · 4 factories claim `[~]`, `delegate_task`, mark `[x]`
· 5 status → `.system/injections.md` `[UNREAD]` · 6 Senter weaves it into the next reply. *"No chat command. No config file. No YAML wizard. Just edit markdown."* ^[raw/sources/knowledge/agent-wiki-repo/spec.md]

## How it actually runs today (2026-09-05)
Four spec crons became: watcher (Layer 1 filing) → topic-worker / topic-agent (skills auto-apply) → umbrella (merges, dedupe, bot promotion) → bridge approvals for
bots/loops only. See [[topics/senter-wiki/wiki/entities/topic-worker-and-topic-wiki-compiler|topic-worker / compiler]], [[topics/senter-wiki/wiki/entities/umbrella|umbrella]],
[[topics/senter-wiki/wiki/concepts/proposal-and-approval-policy|approval policy]], [[topics/senter-wiki/wiki/comparisons/goop-v1-vs-agent-wiki|GOOP v1 vs Agent Wiki]].

## All-caps modules
An all-caps filename (`MEDIA.md`, `WALLET.md`, `RESEARCH.md`) is a user-authored GOOP module: Purpose / Allowed / Forbidden / Approval / Secret References.
*"The Markdown declares policy; Hermes and the sandbox must enforce it."* Secrets are referenced (`bitwarden://wallet/cards`), never stored. ^[raw/sources/knowledge/agent-wiki-repo/SENTER.md]
