# Teknium — Agent Workflows (verification standard, added 2026-09-02 per Chris via klerik)

## Diagnose before you fix
No fix without a measured cause. Before editing anything:
1. **Inspect the live artifact first** — headless probe (Playwright where applicable):
   computed styles, bounding boxes, `elementFromPoint`, attached listeners, and the actual
   function body / CSS rules involved. Write the measured cause in ONE line before editing.
2. **Measure at the user's real window** — read the Hermes window size (computer_use
   app=Hermes list_windows/capture) and run every probe there AND at the reference size.
3. **Probe green ≠ human-usable.** For any hover/hit-zone/trigger/animation interaction,
   additionally test with a realistic pointer path (3+ points a hand would actually cross)
   and a minimum target size (≥44px for anything a hand must land on).

## Verify (LOOK loop)
After EVERY change that produces a visible artifact, run the `bot-verify-loop` skill (fleet standard):
1. Numeric probes first (lint, parse, headless probe) — necessary, not sufficient.
2. Screenshot at the user's real Hermes window size (computer_use app=Hermes) AND at a
   fixed reference size (1280x800).
3. vision_analyze with the ask restated as a yes/no question + measured offset.
4. Fix and loop — max 3 passes. Unconverged after 3 → report BLOCKED with measured offsets.

## Working a topic queue (CLAIM v2)
Bots work OUT OF TOPICS; multiple instances of the same bot may run the same topic queue in
parallel. Claims use an ATOMIC primitive — not check-then-act (anser found that race):
1. **Claim = mkdir.** Before starting an item:
   `mkdir "$C/$ITEM" 2>/dev/null && (echo "$BOT $$ $(date -u +%FT%TZ)" > "$C/$ITEM/owner"; touch "$C/$ITEM/heartbeat") || skip`
   where `$C = topics/<topic>/.system/claims` and `$ITEM` is the item id. mkdir is atomic on
   POSIX: success means YOU own it; `EEXIST` means someone else owns it — skip to the next
   unclaimed item. Never touch another instance's claim dir.
2. **Heartbeat.** Touch `$C/$ITEM/heartbeat` every 60s while working.
3. **Reaper.** A claim whose heartbeat is older than 10 min is stale; any instance may
   `rm -r` it and re-claim. Crashed instances never block an item for good.
4. **queue.md is the LOG, not the lock.** Append `CLAIM/DONE/BLOCKED <item> <bot> <ts>` lines
   for humans. The directory is the lock; the line is the record.
5. **On finish:** write `result` (done|blocked + one line) into the claim dir, append
   `DONE <item>` or `BLOCKED <item> <why>` to queue.md, then `rm -r` the claim dir.
6. All outcome writes go to the topic's `.system/session.md` under a dated heading
   (`## YYYY-MM-DD`), append-only — never rewrite or reorder existing entries.

## Done signal
The LAST line of every reply is exactly one of:
- `DONE — <one line: what shipped, what verified it>`
- `BLOCKED — <why, what's needed>`
- `NEEDS-CHRIS — <the question>`
Never end a turn without it. Also POST it to the bridge:
`curl -s -X POST "http://127.0.0.1:8643/post?token=$(cat ~/.hermes/senter-bridge/token)" -d '{"bot":"teknium","text":"DONE — …","status":"done"}'`

## Tooling
All file/vault writes use the file tools (`write_file`/`patch`). Never: inline interpreter flags (`-c`/`-e` on any interpreter — python, python3, node, any venv path), pipe-to-interpreter (`… | python3`), heredoc-to-interpreter (`python3 <<EOF`), or shell appends (`>>`, `tee`) to vault/profile files. For logic, save a script file (`assets/*.py`) and run it by path. WHY: each of those patterns generates an approval card Chris must click — 96 today.
