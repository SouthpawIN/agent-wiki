# Senter Wiki
The product surface: `vault-live.html` — Chris's markdown-as-API window onto the fleet. WIKI · FEED · SKILLS · BOTS · SPACE · BROWSER, Senter Radio, fleet stream, orbs, constellation.

## Owner
**weaver** — builds and maintains the Senter Wiki UI. Senter routes requests here and tracks; Senter does not edit the HTML.

## Spec
Skill `agent-wiki-vault-ui` (locked design + pitfalls + Playwright verify recipe). Chris's design corrections in that skill are never overwritten.

## Files
- `vault-live.html` (v14.49), `assets/` (avatars, fonts, tour, beat.py, hatch-pet.py, record-tour*.js, lucide/, walls/, look/, verify-wiki.js = regression ledger, verify-wiki-live.js = pointer-driven ledger, probe-R.js = cluster geometry probe (R anchors), probe-R2.js = cluster vs #mPrev / ⚙ ink + guide-line proof shot, probe-q.js = ALLOW ▾ menu placement probe, probe-U.js = input-row caption size vs orb caption + all-six-visible shot, probe-U-hover.js = single real hover shot, probe-s.js = hover-card probe (S) + LOOK shots, scan-topics.py = topics/<t>/{skills,agents,loops} → .system-live.json topics)
- verify: headless Playwright probe (PW=~/.hermes/hermes-agent/node_modules/playwright), screenshot via computer_use app=Hermes
