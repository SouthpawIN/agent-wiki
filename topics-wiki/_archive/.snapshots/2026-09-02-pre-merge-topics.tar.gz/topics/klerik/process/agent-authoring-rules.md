# How to write a bot that works (klerik's rules, distilled from 2026-09-02)
_Every rule here was paid for with a repeat correction today. Klerik applies these to every SOUL/AGENTS it writes or edits._

1. **A bot is spawned when it runs, not when its files exist.** Definition of done: SOUL + AGENTS + model + bridge symlink + `plugins.enabled` + credentials on disk, AND a `-q` smoke turn emits `bridge/loaded`. (paladin was "spawned" twice before it existed.)
2. **Diagnose before you fix.** Inspect the live artifact; write the measured cause in one line before editing. No fix without a cause. (weaver adjusted the strip 6× before anser found the loop in one pass.)
3. **Probe-green ≠ human-usable.** Numeric probes are necessary, not sufficient. Screenshot at the user's REAL window size, vision-check against the ask restated as a yes/no, test hit zones with a realistic pointer path and ≥44px targets.
4. **Verify your own proof.** Before posting DONE, run the same check the coordinator will (vision on your own strip, the assertion you just wrote). Two of teknium's "done" items contradicted its own proof image.
5. **End every reply with DONE / BLOCKED / NEEDS-CHRIS** and POST it to the bridge. A turn without a done line is invisible; the user should never have to guess whether you finished.
6. **Work out of a topic.** Read README + queue first; CLAIM v2 (`mkdir` sidecar + heartbeat) before touching an item; outcomes to `.system/session.md` append-only under a dated heading.
7. **Never route around a gate.** Protected writes surface as approval cards; "Silence is not consent." If the gate times out, say BLOCKED — don't try another path.
8. **No dummy data.** If a live source exists, render from it. If you must fall back to a static list, label it `static · fallback` in the UI and post BLOCKED for the live path. "On disk" ≠ "connected"; "present" ≠ "usable".
9. **Own one thing; name your neighbors.** SOUL states what you own and who owns the adjacent things (weaver: strip/nav/composer; teknium: card animation/data/bridge). Shared-line edits get a note in session.md.
10. **Report as behavior diffs with numbers,** not prose: before → after → how verified → path to the proof.
11. **Transparency beats tidiness.** If you clobbered a file and restored it, say so (klerik did, twice, correctly).
12. **Regression ledger.** Every fix appends one permanent assertion; a failing assertion is a regression to fix, never to delete.
13. **Every standing rule from Chris goes into the owning bot's SOUL the same turn** — a rule said in chat only is held by luck (source: lessons.md #8).
14. **Vault writes use the file tools (`write_file`/`patch`), never inline-exec shell forms** — heredocs (`cat <<EOF`, `python - <<EOF`), `python3 -c "…"`, and `cmd | python3` / `cmd | cat` pipe chains. All of them trip the dangerous-command gate and generate approval cards for ordinary work (81 inline-exec requests on 2026-09-02; one card expired un-approved).
