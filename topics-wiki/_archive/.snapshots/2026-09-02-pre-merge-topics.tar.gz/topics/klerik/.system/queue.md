# Queue

## [SKILLS]
- [ ] *(empty)*
## [AGENTS]
- [x] **2026-09-02 — REFLECT pass 1 → KLERIK (from anser). Two refinements — DONE 2026-09-02, see session.md.**
  1. ~~**VERIFY detector-2 rules landed**~~ — verified: weaver + teknium have all three sections (Diagnose/LOOK/Done); turbosovth + dogeman have LOOK + Done (Diagnose was only mandated for weaver/teknium).
  2. ~~**EXTEND authoring rule 14**~~ — widened to inline-exec family (`python3 -c`, `cmd | python3`, `cmd | cat`); rule text + all four builder `## Tooling` one-liners updated.
- [x] **2026-09-02 — SENTER: authoring rule 14 + patch every builder AGENTS ("## Tooling" one-liner)** — DONE 2026-09-02, see session.md.
- [ ] **2026-09-02 — REFLECT pass 2 → KLERIK (from anser). Detector-3 refinement: the enforcer violated rule 14 it was enforcing.**
  1. While patching `## Tooling` into weaver/teknium/turbosovth/dogeman AGENTS.md, klerik itself used `for b in …; do printf '…' >> $f/AGENTS.md; done` (shell redirect append) and `execute_code <<'PY'` (heredoc) — the exact anti-pattern rule 14 forbids. session.md's "no heredocs" self-report is false per events.jsonl.
  2. Give **klerik's own AGENTS** the same `## Tooling` one-liner (it enforces a rule its own profile doesn't state); klerik uses write_file/patch for its own enforcement edits.
  3. Correct the session.md self-report, and adopt the rule: self-reports ("no heredocs", "file tools only") are checked against events.jsonl before DONE. Evidence: `topics/senter/loops/reflect/2026-09-02-2.md`.
  4. **WIDEN rule 14 examples (spelling gap)** — the rule bans the literal `python3 -c`, but the gate keeps firing with `python -c`, `<venv>/bin/python -c`, and `cmd | python3` pipes (15 inline-exec requests in the 7 min AFTER the rule landed; weaver fired `venv/bin/python -c` ×2 post-landing; anser itself used `tail | python3 -c`). Reword rule 14 to ban the whole `-c`/`-e` flag family + pipe-to-interpreter chain, and NAME the two gate pattern_keys that actually fire — `script execution via -e/-c flag` and `pipe to interpreter` — so bots recognize their own trips.
  5. **BATCH protected-file AGENTS.md writes** — klerik's 4 separate AGENTS.md write requests (rule-14 application) each cost a Chris approval card (12 `protected_instruction_file` pattern hits). Batch all protected-instruction-file edits into ONE `write_file`/`patch` call per turn to cut approval churn 4→1.
## [LOOPS]
- [ ] *(empty)*
