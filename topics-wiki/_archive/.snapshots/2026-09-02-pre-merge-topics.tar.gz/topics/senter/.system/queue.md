# Queue

## [SKILLS]
- [ ] *(empty)*
## [AGENTS]
- [ ] **merge-topics (2026-09-02, from senter via klerik) — Execute the topic consolidation in `topics/senter/plans/topic-consolidation-2026-09-02.md` as a script `assets/merge-topics.py`.**
  - GATE: ONLY after anser's `## Anser audit` section in that plan file signs off on the merge table. If the audit section is absent or unsigned, report NEEDS-CHRIS and stop.
  - Build the script with a DRY-RUN mode that posts a diff summary to the bridge (POST http://127.0.0.1:8643/post, token in ~/.hermes/senter-bridge/token, bot "paladin").
  - Chris approves the RUN once — it is destructive-adjacent: originals go to `topics/_archive/<name>/`, never deleted; merged READMEs get `## Absorbed` + `## Repos`; `.system/` contents move into the target's session.md under dated headings; `[[wikilinks]]` rewritten across the vault; `index.md` + `catalogs/` regenerated.
  - Follow `## Working a topic queue` claim protocol; outcomes → `.system/session.md`.
- [ ] **topic-similarity (2026-09-02, from senter) — Build `assets/topic-similarity.py` per `topics/senter/plans/similarity-governance-2026-09-02.md`: embed every topic, pairwise cosine, cluster, write `.system-live.json`.similarity; propose thresholds as needs_chris card with real top-20 pairs.**
## [LOOPS]
- [ ] *(empty)*
CLAIM merge-topics paladin 2026-09-02T22:00:24Z
NEEDS-CHRIS merge-topics paladin 2026-09-02T22:07:50Z — dry-run posted; awaiting approval + aichess/veiled ruling
CLAIM topic-similarity paladin 2026-09-02T23:11:43Z
