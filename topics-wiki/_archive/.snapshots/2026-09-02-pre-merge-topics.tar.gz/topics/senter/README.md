---
title: senter
updated: 2026-08-29
type: topic
repo: https://github.com/SouthpawIN/Senter
status: active
tags: [senter, goop, hermes-agent, multi-agent, fleet, wiki]
---

# Senter

> **Senter is the three-eyed owl: a self-documenting, self-extending multi-agent system. The wiki IS the coordination layer.**
> This topic now consolidates three repos — agent-wiki (the Senter codebase), klerik (QA/profile-factory agent), and the old senter fleet-orchestrator profile — into ONE project, per the 2026-08-29 cleanup directive.

**Repo:** https://github.com/SouthpawIN/Senter · ACTIVE

## Facts
- **Consolidation date:** 2026-08-29
- **Merged in:** agent-wiki (codebase) · klerik (QA + DSPy/GEPA profile factory) · senter (orchestrator profile)
- **License:** MIT
- **Status:** ACTIVE — repo rename agent-wiki → Senter executed 2026-08-29

## Contents
- `agent-wiki-README.md` — archived README of the old agent-wiki repo (pre-rename)
- `fleet-orchestrator-profile.md` — archived README of the old senter orchestrator repo
- `klerik-profile.md` — klerik identity + role update (profile factory)

## 2026-08-29 session record
See `.system/queue.md` for the full log: turbofit provider fix (4cc6b06), senter HP Omarchy recovery status, turbosovth oversight findings.


## Process (the shareable part) — 2026-09-02
- [[topics/senter/process/build-loop]] — roles, LOOK loop, done signal, approvals, delivery, Meeseeks, PR policy
- [[topics/senter/process/lessons]] — the lessons ledger: what broke → the rule → where it's enforced
- [[topics/senter/process/senter-turn-checklist]] — what Senter checks every turn
- [[topics/klerik/process/agent-authoring-rules]] — how klerik writes bots that work
