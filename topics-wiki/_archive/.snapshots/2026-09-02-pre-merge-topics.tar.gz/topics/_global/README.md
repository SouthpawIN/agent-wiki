---
title: _global
updated: 2026-08-27
type: topic
---

# _global — Fleet Overview

Registries: `.system/agent-roster.md` · `.system/skill-registry.md` · `.system/loop-registry.md`
Dashboards: [[catalogs/fleet-dashboard|Fleet Dashboard]] · [[catalogs/topic-index|Topic Index]]
