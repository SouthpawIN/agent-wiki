---
title: Agent Roster
updated: 2026-08-27
type: catalog
---

# Agent Roster

Named agent profiles across the fleet.

| Agent | Repo | Notes |
|---|---|---|
| klerik | [[topics/klerik/README|repo]] | Hermes Agent meta-profile for reviewing and correcting other agent profiles |
| anser | [[topics/anser/README|repo]] | Hermes Agent tech support moderator for the Nous Research Discord |
| frieza | [[topics/frieza/README|repo]] | Galactic Emperor of Discord — server admin agent for Hermes Agent |
| crow | [[topics/crow/README|repo]] | Crow — deep research agent for Hermes Agent. Produces lore via web search, extraction, and llm-wiki structure. |
| kashik | [[topics/kashik/README|repo]] | Silent historian and librarian — watches agent activity and maintains per-agent llm-wiki documentation |
| veiled | [[topics/veiled/README|repo]] | Veiled — cosmic prose lyricist & song forge Hermes Agent profile |
| llmc | [[topics/llmc/README|repo]] | LLMC — LLM + MC. Your lyric and song companion. Hermes Agent profile. |
| jestur | [[topics/jestur/README|repo]] | Creative studio gremlin Discord DM companion for Hermes Agent |
| test-bot | [[topics/test-bot/README|repo]] | Creative operations bot — Discord DM companion for image, music, and video generation |
| senter | [[topics/senter/README|repo]] | Hermes Agent profile distribution |
| chizul | [[topics/chizul/README|repo]] | Hermes Agent profile distribution |
| nous-girl | [[topics/nous-girl/README|repo]] | Hermes Agent profile distribution |
| nous-girl-agent | [[topics/nous-girl-agent/README|repo]] | Nous Girl agent + OmniStep Evolution Radio plugin — curated local model pet, multimodal by default, voice + music from the model |
| Senter-archive | [[topics/senter-archive/README|repo]] | A lightweight, skill-aware AI agent that uses RAG-based capability discovery. |
