---
title: turbofit
updated: 2026-08-27
type: topic
repo: https://github.com/SouthpawIN/turbofit
status: active
tags: [adaptive-runtime, benchmarking, gguf, gpu, hermes-agent]
---

# turbofit

> Adaptive local inference for Hermes — TurboFit Check, evidence-built TurboFit List, repaired discovery/benchmark campaigns, Qwen 3.8 DFlash2, Bonsai DSpark, FreeToken, and Sirvir.

**[Open on GitHub](https://github.com/SouthpawIN/turbofit)** · ACTIVE · last push 2026-08-27

## Facts
- **Language:** Python
- **Stars / forks:** 83 / 16
- **License:** MIT
- **Fork of:** original work
- **Created:** 2026-06-22 · **Last push:** 2026-08-27
- **Open issues:** 0
- **Status:** ACTIVE
- **Topics:** adaptive-runtime, benchmarking, gguf, gpu, hermes-agent, llama-cpp, local-llm

## From the README

# Turbofit

**One model provider. Every machine. The best local configuration the hardware can safely sustain.**

Turbofit is a first-class [Hermes Agent](https://github.com/NousResearch/hermes-agent) provider and adaptive local-inference runtime. It inventories physical compute and **total usable memory**, recommends an evidence-backed ladder, launches a native backend, and exposes one OpenAI-compatible endpoint. The client-facing name stays `auto` while the backing model, context, and auxiliary mode change.

```text
provider: custom:turbofit
model: auto
```

**TurboFit Check** scans this machine — dedicated VRAM, unified/integrated memory, or RAM-only — and applies Auto or a selected compatible lane. The **[TurboFit List](docs/turbofit-list.md)** is the separate evidence-only winner table by hardware class.

> Catalog entries are **candidates** until the physical campaign passes. Compile, download, or estimated fit is not a winner.

## 2.4 lineup

2.4 keeps the Unleashed / Ornith / Nous-free stack and splits the 8 GB problem into two topologies. **Dedicated VRAM is not the same as total RAM.**

| Model | Entries | Role | Status |
|---|---|---|---|
| **Maple Preview 20B-A1B** | `TQ2_0` | Small-device MoE, ~1B active, native 128K | **Auto on 8 GB at 64K and 128K** |
| **Qwen 3.8 27B Unleashed** | `UD-IQ3_XXS`, `UD-Q3_K_XL` | Uncensored dense 27B, 262K, vision | Active catalog candidates |
| **Ornith 1.5 35A3B** | `Q4_K_M` MoE | Default auxiliary; 16 GB RAM-only main | Active auxiliary candidate |
| **Qwen 3.8 27B** | `Q4_K_M`, `Q8_0`, `BF16` ± MTP | Native image/video | Active catalog candidates |
| **Bonsai 27B** | Q1 / 1-bit | Still in the catalog; no longer the 8 GB Fit List default | Active catalog candidate |
| **MiniMax Music 3** | `minimax-music3` | Full-song music | Pinned integration candidate |
| **NVIDIA Parakeet TDT 0.6B v3** | `parakeet-tdt-0-6b-v3` | Local STT | Pinned integration candidate |
| **Soprano TTS** | `soprano-tts` | Local TTS | Pinned integration candidate |

### Dedicated VRAM

| Capacity | Main path |
|---|---|
| 96 GB+ | Qwen 3.8 27B 16-bit until Unleashed FP16 GGUF exists |
| 24–95 GB | Unleashed UD-Q3_K_XL + DFlash2 |
| 16 GB | Unleashed UD-IQ3_XXS + DFlash2 |
| 8 GB | Maple Preview TQ2_0; Ornith if host RAM can hold offloaded experts |
| Below 8 GB dedicated | Portable-fit only until that box is benched. Never a 9B. |

### Integrated / RAM-only total memory

| Capacity | Main path |
|---|---|
| 24 GB+ | Unleashed UD-Q3_K_XL |
| 16–23 GB | Ornith 1.5 35A3B |
| 8–15 GB | Maple Preview TQ2_0 |


*…truncated — full README at repo link*
