---
title: Fleet Dashboard
updated: 2026-08-27
type: catalog
---

# Fleet Dashboard

**54 repos · 3 active · 0 forks · 50 dormant**

| Topic | Last push | Status |
|---|---|---|
| [[topics/turbofit/README|turbofit]] | 2026-08-27 | ACTIVE |
| [[topics/hermes-agent/README|hermes-agent]] | 2026-08-26 | ACTIVE |
| [[topics/sirvir/README|sirvir]] | 2026-08-24 | ACTIVE |
| [[topics/southpaw-turbohaul/README|southpaw-turbohaul]] | 2026-07-26 | DORMANT (since 2026-07-26) |
| [[topics/memento/README|memento]] | 2026-07-17 | DORMANT (since 2026-07-17) |
| [[topics/hermes-wiki-dashboard/README|hermes-wiki-dashboard]] | 2026-07-15 | DORMANT (since 2026-07-15) |
| [[topics/senter/README|senter]] | 2026-07-14 | ACTIVE (consolidated 2026-08-29) |
| [[topics/hermes-android/README|hermes-android]] | 2026-07-14 | ACTIVE (consolidated 2026-08-29) |
| [[topics/herm-sovth/README|herm-sovth]] | 2026-07-14 | ACTIVE (consolidated 2026-08-29) |
| [[topics/ace-step-daw/README|ACE-Step-DAW]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/sovth-config/README|sovth-config]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/multimodal-expansion/README|multimodal-expansion]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/turbohaul-manager/README|turbohaul-manager]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/niwa/README|niwa]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/pirouette-framework-core-003/README|Pirouette-Framework-CORE-003]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/burner-phone/README|burner-phone]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/sidecar/README|sidecar]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/discordsam/README|DiscordSam]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/pocket-shop-pricing/README|pocket-shop-pricing]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/evolutionary-model-merging/README|evolutionary-model-merging]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/omnistep-fusion/README|omnistep-fusion]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/veiled/README|veiled]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/dev-orch/README|dev-orch]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/dev-review/README|dev-review]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/dev-coder/README|dev-coder]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/nous-test/README|nous-test]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/evolutionary-training/README|evolutionary-training]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/turbohaul-llmfit/README|turbohaul-llmfit]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/nous-style-guide/README|nous-style-guide]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/jestur/README|jestur]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/omnisenter-blog/README|omnisenter-blog]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/hermes-test-skill/README|hermes-test-skill]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/test-bot/README|test-bot]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/benchmark-infographics/README|benchmark-infographics]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/jammit/README|jammit]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| MERGED into [[topics/senter/README|senter]] — klerik profile | — | consolidated 2026-08-29 |
| [[topics/hermes-music-lora-pipeline/README|hermes-music-lora-pipeline]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/nous-girl-agent/README|nous-girl-agent]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/senter/README|senter]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/kashik/README|kashik]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/nous-girl/README|nous-girl]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/southpawin-github-io/README|southpawin.github.io]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/nous-discord-archive/README|nous-discord-archive]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/evolutionary-radio/README|evolutionary-radio]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/pocket-shop/README|pocket-shop]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/anser/README|anser]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/llmc/README|llmc]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/crow/README|crow]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/chizul/README|chizul]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/frieza/README|frieza]] | 2026-07-08 | DORMANT (since 2026-07-08) |
| [[topics/senter-archive/README|Senter-archive]] | 2026-05-11 | ARCHIVED |
| [[topics/flavored-nanocode/README|flavored-nanocode]] | 2026-01-19 | DORMANT (since 2026-01-19) |
| [[topics/openskills/README|openskills]] | 2026-01-18 | DORMANT (since 2026-01-18) |
| [[topics/aichess/README|AIChess]] | 2025-07-25 | DORMANT (since 2025-07-25) |
