---
title: Topic Index
updated: 2026-08-27
type: catalog
---

# Topic Index

All 54 repos, one topic each. Active first.

| Topic | Repo | Status | ⭐ |
|---|---|---|---|
| [[topics/turbofit/README|turbofit]] | [repo](https://github.com/SouthpawIN/turbofit) | ACTIVE | 83 |
| [[topics/hermes-agent/README|hermes-agent]] | [repo](https://github.com/SouthpawIN/hermes-agent) | ACTIVE | 2 |
| [[topics/sirvir/README|sirvir]] | [repo](https://github.com/SouthpawIN/sirvir) | ACTIVE | 27 |
| [[topics/southpaw-turbohaul/README|southpaw-turbohaul]] | [repo](https://github.com/SouthpawIN/southpaw-turbohaul) | DORMANT (since 2026-07-26) | 7 |
| [[topics/memento/README|memento]] | [repo](https://github.com/SouthpawIN/memento) | DORMANT (since 2026-07-17) | 0 |
| [[topics/hermes-wiki-dashboard/README|hermes-wiki-dashboard]] | [repo](https://github.com/SouthpawIN/hermes-wiki-dashboard) | DORMANT (since 2026-07-15) | 1 |
| [[topics/senter/README|senter]] | [repo](https://github.com/SouthpawIN/Senter) | ACTIVE (consolidated 2026-08-29) | 22 |
| [[topics/hermes-android/README|hermes-android]] | [repo](https://github.com/SouthpawIN/hermes-android) | ACTIVE (consolidated 2026-08-29) | 3 |
| [[topics/herm-sovth/README|herm-sovth]] | [repo](https://github.com/SouthpawIN/herm-sovth) | ACTIVE (consolidated 2026-08-29) | 3 |
| [[topics/ace-step-daw/README|ACE-Step-DAW]] | [repo](https://github.com/SouthpawIN/ACE-Step-DAW) | DORMANT (since 2026-07-08) | 0 |
| [[topics/sovth-config/README|sovth-config]] | [repo](https://github.com/SouthpawIN/sovth-config) | DORMANT (since 2026-07-08) | 17 |
| [[topics/multimodal-expansion/README|multimodal-expansion]] | [repo](https://github.com/SouthpawIN/multimodal-expansion) | DORMANT (since 2026-07-08) | 4 |
| [[topics/turbohaul-manager/README|turbohaul-manager]] | [repo](https://github.com/SouthpawIN/turbohaul-manager) | DORMANT (since 2026-07-08) | 1 |
| [[topics/niwa/README|niwa]] | [repo](https://github.com/SouthpawIN/niwa) | DORMANT (since 2026-07-08) | 1 |
| [[topics/pirouette-framework-core-003/README|Pirouette-Framework-CORE-003]] | [repo](https://github.com/SouthpawIN/Pirouette-Framework-CORE-003) | DORMANT (since 2026-07-08) | 0 |
| [[topics/burner-phone/README|burner-phone]] | [repo](https://github.com/SouthpawIN/burner-phone) | DORMANT (since 2026-07-08) | 53 |
| [[topics/sidecar/README|sidecar]] | [repo](https://github.com/SouthpawIN/sidecar) | DORMANT (since 2026-07-08) | 1 |
| [[topics/discordsam/README|DiscordSam]] | [repo](https://github.com/SouthpawIN/DiscordSam) | DORMANT (since 2026-07-08) | 1 |
| [[topics/pocket-shop-pricing/README|pocket-shop-pricing]] | [repo](https://github.com/SouthpawIN/pocket-shop-pricing) | DORMANT (since 2026-07-08) | 1 |
| [[topics/evolutionary-model-merging/README|evolutionary-model-merging]] | [repo](https://github.com/SouthpawIN/evolutionary-model-merging) | DORMANT (since 2026-07-08) | 19 |
| [[topics/omnistep-fusion/README|omnistep-fusion]] | [repo](https://github.com/SouthpawIN/omnistep-fusion) | DORMANT (since 2026-07-08) | 2 |
| [[topics/veiled/README|veiled]] | [repo](https://github.com/SouthpawIN/veiled) | DORMANT (since 2026-07-08) | 1 |
| [[topics/dev-orch/README|dev-orch]] | [repo](https://github.com/SouthpawIN/dev-orch) | DORMANT (since 2026-07-08) | 1 |
| [[topics/dev-review/README|dev-review]] | [repo](https://github.com/SouthpawIN/dev-review) | DORMANT (since 2026-07-08) | 1 |
| [[topics/dev-coder/README|dev-coder]] | [repo](https://github.com/SouthpawIN/dev-coder) | DORMANT (since 2026-07-08) | 1 |
| [[topics/nous-test/README|nous-test]] | [repo](https://github.com/SouthpawIN/nous-test) | DORMANT (since 2026-07-08) | 1 |
| [[topics/evolutionary-training/README|evolutionary-training]] | [repo](https://github.com/SouthpawIN/evolutionary-training) | DORMANT (since 2026-07-08) | 6 |
| [[topics/turbohaul-llmfit/README|turbohaul-llmfit]] | [repo](https://github.com/SouthpawIN/turbohaul-llmfit) | DORMANT (since 2026-07-08) | 2 |
| [[topics/nous-style-guide/README|nous-style-guide]] | [repo](https://github.com/SouthpawIN/nous-style-guide) | DORMANT (since 2026-07-08) | 2 |
| [[topics/jestur/README|jestur]] | [repo](https://github.com/SouthpawIN/jestur) | DORMANT (since 2026-07-08) | 1 |
| [[topics/omnisenter-blog/README|omnisenter-blog]] | [repo](https://github.com/SouthpawIN/omnisenter-blog) | DORMANT (since 2026-07-08) | 1 |
| [[topics/hermes-test-skill/README|hermes-test-skill]] | [repo](https://github.com/SouthpawIN/hermes-test-skill) | DORMANT (since 2026-07-08) | 0 |
| [[topics/test-bot/README|test-bot]] | [repo](https://github.com/SouthpawIN/test-bot) | DORMANT (since 2026-07-08) | 0 |
| [[topics/benchmark-infographics/README|benchmark-infographics]] | [repo](https://github.com/SouthpawIN/benchmark-infographics) | DORMANT (since 2026-07-08) | 0 |
| [[topics/jammit/README|jammit]] | [repo](https://github.com/SouthpawIN/jammit) | DORMANT (since 2026-07-08) | 11 |
| MERGED into [[topics/senter/README|senter]] — klerik profile | — | consolidated 2026-08-29 | 9 |
| [[topics/hermes-music-lora-pipeline/README|hermes-music-lora-pipeline]] | [repo](https://github.com/SouthpawIN/hermes-music-lora-pipeline) | DORMANT (since 2026-07-08) | 5 |
| [[topics/nous-girl-agent/README|nous-girl-agent]] | [repo](https://github.com/SouthpawIN/nous-girl-agent) | DORMANT (since 2026-07-08) | 5 |
| MERGED into [[topics/senter/README|senter]] — orchestrator profile | — | consolidated 2026-08-29 | 3 |
| [[topics/kashik/README|kashik]] | [repo](https://github.com/SouthpawIN/kashik) | DORMANT (since 2026-07-08) | 2 |
| [[topics/nous-girl/README|nous-girl]] | [repo](https://github.com/SouthpawIN/nous-girl) | DORMANT (since 2026-07-08) | 1 |
| [[topics/southpawin-github-io/README|southpawin.github.io]] | [repo](https://github.com/SouthpawIN/southpawin.github.io) | DORMANT (since 2026-07-08) | 1 |
| [[topics/nous-discord-archive/README|nous-discord-archive]] | [repo](https://github.com/SouthpawIN/nous-discord-archive) | DORMANT (since 2026-07-08) | 0 |
| [[topics/evolutionary-radio/README|evolutionary-radio]] | [repo](https://github.com/SouthpawIN/evolutionary-radio) | DORMANT (since 2026-07-08) | 9 |
| [[topics/pocket-shop/README|pocket-shop]] | [repo](https://github.com/SouthpawIN/pocket-shop) | DORMANT (since 2026-07-08) | 7 |
| [[topics/anser/README|anser]] | [repo](https://github.com/SouthpawIN/anser) | DORMANT (since 2026-07-08) | 6 |
| [[topics/llmc/README|llmc]] | [repo](https://github.com/SouthpawIN/llmc) | DORMANT (since 2026-07-08) | 5 |
| [[topics/crow/README|crow]] | [repo](https://github.com/SouthpawIN/crow) | DORMANT (since 2026-07-08) | 2 |
| [[topics/chizul/README|chizul]] | [repo](https://github.com/SouthpawIN/chizul) | DORMANT (since 2026-07-08) | 1 |
| [[topics/frieza/README|frieza]] | [repo](https://github.com/SouthpawIN/frieza) | DORMANT (since 2026-07-08) | 0 |
| [[topics/senter-archive/README|Senter-archive]] | [repo](https://github.com/SouthpawIN/Senter-archive) | ARCHIVED | 6 |
| [[topics/flavored-nanocode/README|flavored-nanocode]] | [repo](https://github.com/SouthpawIN/flavored-nanocode) | DORMANT (since 2026-01-19) | 1 |
| [[topics/openskills/README|openskills]] | [repo](https://github.com/SouthpawIN/openskills) | DORMANT (since 2026-01-18) | 1 |
| [[topics/aichess/README|AIChess]] | [repo](https://github.com/SouthpawIN/AIChess) | DORMANT (since 2025-07-25) | 1 |
